package com.example.example6_1_2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.example6_1_2.R;

public class MainActivity extends AppCompatActivity {

    ActivityResultLauncher<Intent> launcer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnNewActivity = findViewById(R.id.btnNewActivity);
        EditText editText = findViewById(R.id.EditText);
        EditText editText2 = findViewById(R.id.EditText2);

        btnNewActivity.setOnClickListener(new View.OnClickListener() { //익명객체 new ~
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class); //MainActivity에서 SubActivity로 넘어갈껍니다
                intent.putExtra("name", editText.getText().toString()); //가져온 에딧텍스트의 텍스트 타입을 스트링 타입으로
                intent.putExtra("age", Integer.valueOf(editText2.getText().toString()));
                //startActivity(intent); : 단방향
                launcer.launch(intent); // 양방향

            }
        });

        //registerForActivityResult : 다른 액티비티를 실행하고, 그 결과를 처리할 때 사용되는 메서드
        //ActivityResultContracts.StartActivityForResult(): 호출된 액티비티가 종료될 때 결과 코드와 데이터가 반환됩니다.
        //ActivityResultCallback: 이 콜백 함수는 다른 액티비티가 종료될 때 호출
        launcer = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult o) {
                if(o.getResultCode() == RESULT_OK) { // o.getResultCode()로 결과 코드를 확인하고, RESULT_OK인 경우에만 이후 작업을 수행하도록
                    Intent data = o.getData(); // 다른 액티비티에서 전달된 인텐트(Intent) 객체를 가져옴
                    String result = data.getStringExtra("result"); //getStringExtra("result")를 사용해 **“result”**라는 키에 저장된 문자열 데이터를 가져옴
                    Toast.makeText(MainActivity.this, "결과 : " + result, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}