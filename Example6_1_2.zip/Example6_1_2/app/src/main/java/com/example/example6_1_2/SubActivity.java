package com.example.example6_1_2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.example6_1_2.R;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnReturn = findViewById(R.id.btnReturn); //파인드뷰바이아이디로 아이디 연결하는거
        TextView textView = findViewById(R.id.textView);
        TextView textView2 = findViewById(R.id.textView2);

        Intent intent2 = getIntent();
        String strName = intent2.getStringExtra("name");
        textView.setText(strName);

        int num = intent2.getIntExtra("age", 0);
        textView2.setText(String.valueOf(num));

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent outIntent
                        = new Intent(getApplicationContext(),
                        MainActivity.class); //Intent 객체를 생성하여 현재 액티비티의 데이터를 MainActivity에 전달할 준비
                                            // getApplicationContext()는 현재 애플리케이션의 전체 컨텍스트를 가져오는 메서드
                outIntent.putExtra("result", strName); //	putExtra 메서드를 사용해 “result”라는 키에 strName 값을 담음
                setResult(RESULT_OK, outIntent); // setResult 메서드를 사용해 결과 코드와 데이터를 설정,
                                                 // RESULT_OK는 정상적으로 처리되었음을 의미하는 결과 코드
                                                 //  outIntent 인텐트에 담긴 데이터가 호출한 액티비티로 전달됨
                finish(); //액티비티 종료

            }
        });
    }
}