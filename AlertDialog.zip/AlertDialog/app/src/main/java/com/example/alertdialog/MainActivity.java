package com.example.alertdialog;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);


        button1.setOnClickListener(new View.OnClickListener() { //버튼1이 눌렷을 때 (리스너 구현 클래스)
            @Override
            public void onClick(View view) { //온클릭 메소드 재정리
                //대화상자 띄우는 코드
                AlertDialog.Builder dlg=new AlertDialog.Builder(MainActivity.this); // 다이얼로그 대화상자를 하나 띄워 봅시다
                dlg.setTitle("제목입니다");
                dlg.setMessage("내용입니다");
                dlg.setIcon(R.mipmap.ic_launcher); //이거 안드로이드 동그란 초록 아이콘 추가
                dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            //확인버튼 (오른쪽 하단으로 위치)
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(MainActivity.this, "확인", Toast.LENGTH_SHORT).show();
                            }
                });
                dlg.setNegativeButton("ㅎㅇ", null); //확인버튼 (오른쪽 하단으로 위치)
                dlg.setNeutralButton("gd", null); //확인버튼 (왼쪽 하단으로 위치)

                dlg.show(); // 쇼를 해야만 dlg가 불러와짐
            }
        });

        String[] versionArray = new String[] {"쫄면", "떡볶이", "김밥"};
        button2.setOnClickListener(new View.OnClickListener() { //버튼1이 눌렷을 때 (리스너 구현 클래스)
            @Override
            public void onClick(View view) { //온클릭 메소드 재정리
                //대화상자 띄우는 코드
                AlertDialog.Builder dlg=new AlertDialog.Builder(MainActivity.this); // 다이얼로그 대화상자를 하나 띄워 봅시다
                dlg.setTitle("좋아하는 간식은?");
                dlg.setItems(versionArray, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        button2.setText(versionArray[i]);
                    }
                });
                dlg.setPositiveButton("닫기", null);
                dlg.show();
            }
        });

        //라디오 버튼은 딱 한개만 선택 가능한 -> SingleChoiceItems
        button3.setOnClickListener(new View.OnClickListener() { //버튼1이 눌렷을 때 (리스너 구현 클래스)
            @Override
            public void onClick(View view) { //온클릭 메소드 재정리
                //대화상자 띄우는 코드
                AlertDialog.Builder dlg=new AlertDialog.Builder(MainActivity.this); // 다이얼로그 대화상자를 하나 띄워 봅시다
                dlg.setTitle("좋아하는 간식은?");
                dlg.setIcon(R.mipmap.ic_launcher_round);

                dlg.setSingleChoiceItems(versionArray, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        button3.setText(versionArray[i]);
                    }
                });
                dlg.setPositiveButton("닫기", null);
                dlg.show();
            }
        });


        //이거 왜하는 거
        boolean[] checkArray = new boolean[] {false, false, false};

        button4.setOnClickListener(new View.OnClickListener() { //버튼1이 눌렷을 때 (리스너 구현 클래스)
            @Override
            public void onClick(View view) { //온클릭 메소드 재정리
                //대화상자 띄우는 코드
                AlertDialog.Builder dlg=new AlertDialog.Builder(MainActivity.this); // 다이얼로그 대화상자를 하나 띄워 봅시다
                dlg.setTitle("좋아하는 간식은?");
                dlg.setIcon(R.mipmap.ic_launcher);
                dlg.setMultiChoiceItems(versionArray, checkArray, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                        Toast.makeText(MainActivity.this, versionArray[i]+"선택됨", Toast.LENGTH_SHORT).show();
                    }
                });
                dlg.setPositiveButton("닫기", null);
                dlg.show();
            }
        });


        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dateDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        button5.setText(i+" "+i1+" "+i2);
                    }
                }, year, month, day);
                dateDialog.show();
            }
        });


        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);

                TimePickerDialog timeDialog = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        button6.setText(i + " " + i1);
                    }
                }, hour, minute, false);
                timeDialog.show();

            }
        });
    }
}
